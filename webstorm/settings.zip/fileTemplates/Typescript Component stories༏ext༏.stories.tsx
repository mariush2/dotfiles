import { useState } from 'react';

import { Story } from '@storybook/react';

export default {
  title: 'PATH',
  component: COMPONENT,
  argTypes: {
    label: { control: 'text' } 
  },
  args: {
    label: 'label'
  },
};

export const Primary: Story<PROPS> = (args) => {
  return null
};
