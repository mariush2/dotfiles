import { faker } from '@faker-js/faker';

import { render, screen } from 'test-utils';

test('this is the test', async () => {
    render()
});